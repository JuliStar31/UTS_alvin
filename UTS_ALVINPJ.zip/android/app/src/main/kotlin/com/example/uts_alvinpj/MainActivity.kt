package com.example.uts_alvinpj

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
